<?php
/**
 * Plugin Name: urZONE PVE Settings
 * Plugin URI:  https://urzone.org/
 * Description: Adds a "urZONE PVE" menu to the WordPress admin where you connect Proxmox VE, set defaults and limits, and review limits. Works alongside urZONE PVE Core. Free.
 * Version:     2.1.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author:      Osiris Simmons (Osiris83)
 * Author URI:  https://urzone.org
 * License:     GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: urzone-pve-settings
 */

defined( 'ABSPATH' ) || exit;

// If another copy of this file / the old Settings plugin is already loaded, do nothing.
if ( defined( 'URZONE_PVE_SETTINGS_LOADED' ) ) {
	return;
}

define( 'URZONE_PVE_SETTINGS_LOADED', true );

/**
 * Applies the "max cores / memory / disk" settings to customer plans through the
 * 'urzone_pve_caps' filter the core plugin provides. Administrators and
 * the demo are left alone.
 */
add_filter(
	'urzone_pve_caps',
	static function ( $caps, $plan ) {
		if ( ! empty( $plan['admin'] ) || ! empty( $plan['demo'] ) ) {
			return $caps;
		}

		$map = array(
			'cores'  => 'URZONE_PROXMOX_MAX_CORES',
			'memory' => 'URZONE_PROXMOX_MAX_MEMORY',
			'disk'   => 'URZONE_PROXMOX_MAX_DISK_GB',
		);

		foreach ( $map as $key => $const ) {
			if ( defined( $const ) && (int) constant( $const ) > 0 && isset( $caps[ $key ] ) ) {
				$caps[ $key ] = min( (int) $caps[ $key ], (int) constant( $const ) );
			}
		}

		return $caps;
	},
	10,
	2
);

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

/** Only super admins on multisite; manage_options on a single site. Deliberately not filterable. */
function urzone_pve_set_can() {
	return is_multisite() ? is_super_admin() : current_user_can( 'manage_options' );
}

function urzone_pve_set_const( $name ) {
	return defined( $name ) ? (string) constant( $name ) : '';
}

/**
 * Connection details handed to people who do NOT run their own Proxmox.
 * Supply them with the 'urzone_pve_managed_preset' filter (do not hard-code a
 * secret in a plugin you distribute).
 */
function urzone_pve_set_preset() {
	$d = array(
		'url'      => defined( 'URZONE_PVE_MANAGED_URL' ) ? (string) URZONE_PVE_MANAGED_URL : '',
		'user'     => defined( 'URZONE_PVE_MANAGED_USER' ) ? (string) URZONE_PVE_MANAGED_USER : '',
		'token_id' => defined( 'URZONE_PVE_MANAGED_TOKEN_ID' ) ? (string) URZONE_PVE_MANAGED_TOKEN_ID : '',
		'secret'   => defined( 'URZONE_PVE_MANAGED_SECRET' ) ? (string) URZONE_PVE_MANAGED_SECRET : '',
	);
	$p = apply_filters( 'urzone_pve_managed_preset', $d );

	return array_map( 'strval', array_merge( $d, is_array( $p ) ? array_intersect_key( $p, $d ) : array() ) );
}

/** Part 2 settings: one definition drives the form, validation and wp-config output. */
function urzone_pve_set_option_fields() {
	return array(
		'sslverify'     => array( 'const' => 'URZONE_PROXMOX_SSLVERIFY', 'default' => false, 'type' => 'bool', 'label' => 'Verify SSL certificate', 'help' => 'Leave off for the self-signed certificate Proxmox ships with. Turn on only if your Proxmox host has a certificate this web server trusts.' ),
		'node'          => array( 'const' => 'URZONE_PROXMOX_DEFAULT_NODE', 'default' => 'pve', 'type' => 'id', 'label' => 'Default node', 'help' => 'Node name exactly as shown in the Proxmox sidebar (case-sensitive), e.g. pve.' ),
		'storage'       => array( 'const' => 'URZONE_PROXMOX_DEFAULT_STORAGE', 'default' => 'local-lvm', 'type' => 'id', 'label' => 'Default storage', 'help' => 'Where new disks and container root filesystems are created, e.g. local-lvm.' ),
		'bridge'        => array( 'const' => 'URZONE_PROXMOX_DEFAULT_BRIDGE', 'default' => 'vmbr0', 'type' => 'id', 'label' => 'Default network bridge', 'help' => 'Bridge new guests attach to, e.g. vmbr0.' ),
		'tpl_storage'   => array( 'const' => 'URZONE_PROXMOX_TEMPLATE_STORAGE', 'default' => 'local', 'type' => 'id', 'label' => 'Container template storage', 'help' => 'Storage that holds your LXC templates, e.g. local.' ),
		'iso_storage'   => array( 'const' => 'URZONE_PROXMOX_ISO_STORAGE', 'default' => 'local', 'type' => 'id', 'label' => 'ISO storage', 'help' => 'Storage that holds your ISO images, e.g. local.' ),
		'max_instances' => array( 'const' => 'URZONE_PROXMOX_MAX_INSTANCES', 'default' => 5, 'type' => 'int', 'min' => 1, 'max' => 1000, 'label' => 'Max instances (no-plan users)', 'help' => 'Only used for users who have no plan role. Each plan keeps its own limit.' ),
		'poll'          => array( 'const' => 'URZONE_PROXMOX_POLL_SECONDS', 'default' => 5, 'type' => 'int', 'min' => 3, 'max' => 300, 'label' => 'Live refresh (seconds)', 'help' => 'How often the dashboard charts refresh. Minimum 3.' ),
		'max_cores'     => array( 'const' => 'URZONE_PROXMOX_MAX_CORES', 'default' => 64, 'type' => 'int', 'min' => 1, 'max' => 512, 'label' => 'Max CPU cores per instance', 'help' => 'Ceiling for customer plans. Administrators are not limited by this.' ),
		'max_memory'    => array( 'const' => 'URZONE_PROXMOX_MAX_MEMORY', 'default' => 1048576, 'type' => 'int', 'min' => 256, 'max' => 4194304, 'label' => 'Max memory per instance (MB)', 'help' => 'Ceiling for customer plans, in megabytes (8192 = 8 GB).' ),
		'max_disk'      => array( 'const' => 'URZONE_PROXMOX_MAX_DISK_GB', 'default' => 2048, 'type' => 'int', 'min' => 1, 'max' => 65536, 'label' => 'Max disk per instance (GB)', 'help' => 'Ceiling for customer plans, in gigabytes.' ),
	);
}

/** How the Defaults tab is grouped on screen. */
function urzone_pve_set_groups() {
	return array(
		array( 'Where new instances go', 'Names must match Proxmox exactly (they are case-sensitive).', array( 'node', 'storage', 'bridge', 'tpl_storage', 'iso_storage' ) ),
		array( 'Behaviour', 'How the plugin talks to Proxmox and refreshes the dashboard.', array( 'sslverify', 'poll', 'max_instances' ) ),
		array( 'Size limits per instance', 'Ceilings for customer plans. Administrators and the demo are not affected.', array( 'max_cores', 'max_memory', 'max_disk' ) ),
	);
}

/** Effective values: whatever PHP currently has loaded from wp-config.php / plugin defaults. */
function urzone_pve_set_current() {
	$c = array(
		'url'      => urzone_pve_set_const( 'URZONE_PROXMOX_API_URL' ),
		'user'     => urzone_pve_set_const( 'URZONE_PROXMOX_API_USER' ),
		'token_id' => urzone_pve_set_const( 'URZONE_PROXMOX_API_TOKEN_ID' ),
		'secret'   => urzone_pve_set_const( 'URZONE_PROXMOX_API_TOKEN_SECRET' ),
	);

	foreach ( urzone_pve_set_option_fields() as $key => $f ) {
		$c[ $key ] = defined( $f['const'] ) ? constant( $f['const'] ) : $f['default'];
	}

	return $c;
}

/*
|--------------------------------------------------------------------------
| wp-config.php writer
|--------------------------------------------------------------------------
*/

function urzone_pve_set_config_path() {
	$path = ABSPATH . 'wp-config.php';

	if ( ! file_exists( $path ) ) {
		$parent = dirname( untrailingslashit( ABSPATH ) );
		$path   = $parent . '/wp-config.php';

		// WordPress allows wp-config.php one level up, unless that is another WP install.
		if ( ! file_exists( $path ) || file_exists( $parent . '/wp-settings.php' ) ) {
			$path = '';
		}
	}

	return (string) apply_filters( 'urzone_pve_wpconfig_path', $path );
}

function urzone_pve_set_php_value( $v ) {
	if ( is_bool( $v ) ) {
		return $v ? 'true' : 'false';
	}

	if ( is_int( $v ) ) {
		return (string) $v;
	}

	return var_export( (string) $v, true );
}

function urzone_pve_set_block( $section, $values ) {
	$lines = array( '/* BEGIN urZONE PVE ' . $section . ' (managed by the urZONE PVE settings page) */' );

	foreach ( $values as $name => $v ) {
		$lines[] = "define( '" . $name . "', " . urzone_pve_set_php_value( $v ) . ' );';
	}

	$lines[] = '/* END urZONE PVE ' . $section . ' */';

	return implode( "\n", $lines ) . "\n";
}

function urzone_pve_set_strip_comments( $code ) {
	if ( ! function_exists( 'token_get_all' ) ) {
		return $code;
	}

	$out = '';

	foreach ( token_get_all( $code ) as $t ) {
		if ( is_array( $t ) ) {
			if ( in_array( $t[0], array( T_COMMENT, T_DOC_COMMENT ), true ) ) {
				continue;
			}
			$out .= $t[1];
		} else {
			$out .= $t;
		}
	}

	return $out;
}

/** Puts the block above the "stop editing" comment, or above the wp-settings.php require. */
function urzone_pve_set_insert( $content, $block ) {
	$patterns = array(
		'/\/\*\s*That.s all, stop editing/i',
		'/^[ \t]*require_once\s+[^;]*wp-settings\.php/m',
	);

	foreach ( $patterns as $pattern ) {
		if ( preg_match( $pattern, $content, $m, PREG_OFFSET_CAPTURE ) ) {
			$offset = (int) $m[0][1];
			$nl     = strrpos( substr( $content, 0, $offset ), "\n" );
			$pos    = false === $nl ? 0 : $nl + 1;

			return substr( $content, 0, $pos ) . $block . "\n" . substr( $content, $pos );
		}
	}

	return null;
}

/** Writes (or replaces) one managed block. Returns the path or a WP_Error. */
function urzone_pve_set_write( $section, $values ) {
	$path = urzone_pve_set_config_path();

	if ( '' === $path ) {
		return new WP_Error( 'nofile', 'wp-config.php was not found.' );
	}

	if ( ! is_readable( $path ) || ! is_writable( $path ) ) {
		return new WP_Error( 'notwritable', 'wp-config.php is not writable by the web server.' );
	}

	$orig = file_get_contents( $path );

	if ( false === $orig || false === strpos( $orig, 'wp-settings.php' ) ) {
		return new WP_Error( 'unreadable', 'wp-config.php could not be read, or does not look like a normal WordPress config.' );
	}

	$block = urzone_pve_set_block( $section, $values );
	$re    = '#/\* BEGIN urZONE PVE ' . preg_quote( $section, '#' ) . '\b.*?/\* END urZONE PVE ' . preg_quote( $section, '#' ) . ' \*/\n?#s';

	// Refuse to create duplicate define()s (ignoring anything inside comments).
	$without = urzone_pve_set_strip_comments( preg_replace( $re, '', $orig ) );
	$dups    = array();

	foreach ( array_keys( $values ) as $name ) {
		if ( preg_match( '/define\s*\(\s*([\'"])' . preg_quote( $name, '/' ) . '\1/', $without ) ) {
			$dups[] = $name;
		}
	}

	if ( $dups ) {
		return new WP_Error( 'dups', 'wp-config.php already defines ' . implode( ', ', $dups ) . ' outside the managed block. Delete those lines from wp-config.php, then save again.' );
	}

	if ( preg_match( $re, $orig ) ) {
		$new = preg_replace_callback(
			$re,
			static function () use ( $block ) {
				return $block;
			},
			$orig,
			1
		);
	} else {
		$new = urzone_pve_set_insert( $orig, $block );

		if ( null === $new ) {
			return new WP_Error( 'noanchor', 'Could not find where to insert the settings in wp-config.php (no "stop editing" comment or wp-settings.php line).' );
		}
	}

	// Syntax-check the result before it can break the site.
	if ( function_exists( 'token_get_all' ) && defined( 'TOKEN_PARSE' ) ) {
		try {
			token_get_all( $new, TOKEN_PARSE );
		} catch ( \Throwable $e ) {
			return new WP_Error( 'syntax', 'The resulting wp-config.php would not be valid PHP, so nothing was changed: ' . $e->getMessage() );
		}
	}

	// Backup. It is a .php file that exits on its first line, so it can never be downloaded as plain text.
	$backup = dirname( $path ) . '/wp-config-urzone-backup.php';

	if ( false === file_put_contents( $backup, "<?php exit; ?>\n" . $orig, LOCK_EX ) ) {
		return new WP_Error( 'backup', 'Could not create a backup next to wp-config.php, so nothing was changed.' );
	}

	@chmod( $backup, 0600 ); // phpcs:ignore

	$bytes = file_put_contents( $path, $new, LOCK_EX );

	if ( false === $bytes || file_get_contents( $path ) !== $new ) {
		file_put_contents( $path, $orig, LOCK_EX ); // Restore.

		return new WP_Error( 'write', 'Writing wp-config.php failed; the original was restored.' );
	}

	if ( function_exists( 'opcache_invalidate' ) ) {
		@opcache_invalidate( $path, true ); // phpcs:ignore
	}

	return $path;
}

/*
|--------------------------------------------------------------------------
| Connection test (uses explicit values, so it works before wp-config reloads)
|--------------------------------------------------------------------------
*/

function urzone_pve_set_api( $c, $path ) {
	$token = trim( (string) $c['token_id'] );

	if ( false !== strpos( $token, '!' ) ) {
		$parts = explode( '!', $token, 2 );
		$token = $parts[1];
	}

	$res = wp_remote_get(
		rtrim( (string) $c['url'], '/' ) . '/' . ltrim( $path, '/' ),
		array(
			'timeout'     => 10,
			'redirection' => 0,
			'sslverify'   => (bool) $c['sslverify'],
			'headers'     => array(
				'Accept'        => 'application/json',
				'Authorization' => sprintf( 'PVEAPIToken=%s!%s=%s', $c['user'], $token, $c['secret'] ),
			),
		)
	);

	if ( is_wp_error( $res ) ) {
		$m = $res->get_error_message();

		if ( false !== stripos( $m, 'certificate' ) || false !== stripos( $m, 'SSL' ) ) {
			$m .= ' (If Proxmox uses its default self-signed certificate, turn "Verify SSL certificate" off.)';
		}

		return array( 'ok' => false, 'error' => $m );
	}

	$code = (int) wp_remote_retrieve_response_code( $res );
	$data = json_decode( wp_remote_retrieve_body( $res ), true );

	if ( $code < 200 || $code >= 300 ) {
		$m = 'HTTP ' . $code . ' ' . wp_remote_retrieve_response_message( $res ) . '.';

		if ( 401 === $code || 403 === $code ) {
			$m .= ' Check the API user, token ID and secret (Datacenter > Permissions > API Tokens).';
		}

		return array( 'ok' => false, 'error' => $m );
	}

	return array( 'ok' => true, 'data' => is_array( $data ) && isset( $data['data'] ) ? $data['data'] : array() );
}

/** Returns rows of array( status ok|warn|fail, label, detail ). */
function urzone_pve_set_test( $c ) {
	$rows = array();
	$add  = static function ( $s, $l, $d = '' ) use ( &$rows ) {
		$rows[] = array( $s, $l, $d );
	};

	$v = urzone_pve_set_api( $c, '/version' );

	if ( ! $v['ok'] ) {
		$add( 'fail', 'Connect and authenticate', $v['error'] );

		return $rows;
	}

	$add( 'ok', 'Connected and authenticated', 'Proxmox VE ' . ( is_array( $v['data'] ) && isset( $v['data']['version'] ) ? $v['data']['version'] : '(version unknown)' ) );

	$node = (string) $c['node'];
	$base = '/nodes/' . rawurlencode( $node );
	$list = urzone_pve_set_api( $c, '/nodes' );

	if ( $list['ok'] ) {
		$names = array_map( 'strval', wp_list_pluck( (array) $list['data'], 'node' ) );

		if ( in_array( $node, $names, true ) ) {
			$add( 'ok', 'Node "' . $node . '" exists' );
		} else {
			$add( 'fail', 'Node "' . $node . '" not found', 'Nodes this token can see: ' . ( $names ? implode( ', ', $names ) : 'none' ) . '. Node names are case-sensitive.' );

			return $rows;
		}
	} else {
		$add( 'warn', 'Could not list nodes', $list['error'] );
	}

	$st = urzone_pve_set_api( $c, $base . '/storage' );

	if ( $st['ok'] ) {
		$by = array();

		foreach ( (array) $st['data'] as $s ) {
			if ( is_array( $s ) && isset( $s['storage'] ) ) {
				$by[ (string) $s['storage'] ] = (string) ( $s['content'] ?? '' );
			}
		}

		$checks = array(
			array( (string) $c['storage'], array( 'rootdir', 'images' ), 'Default storage' ),
			array( (string) $c['tpl_storage'], array( 'vztmpl' ), 'Container template storage' ),
			array( (string) $c['iso_storage'], array( 'iso' ), 'ISO storage' ),
		);

		foreach ( $checks as $chk ) {
			list( $name, $needs, $label ) = $chk;

			if ( ! isset( $by[ $name ] ) ) {
				$add( 'fail', $label . ' "' . $name . '" not found', 'Storages on this node: ' . ( $by ? implode( ', ', array_keys( $by ) ) : 'none' ) );
				continue;
			}

			$have = array_map( 'trim', explode( ',', $by[ $name ] ) );

			if ( ! array_intersect( $needs, $have ) ) {
				$add( 'warn', $label . ' "' . $name . '" exists but is not enabled for ' . implode( ' / ', $needs ) . ' content', 'Enable it under Datacenter > Storage in Proxmox.' );
			} else {
				$add( 'ok', $label . ' "' . $name . '" is available' );
			}
		}
	} else {
		$add( 'warn', 'Could not list storage', $st['error'] );
	}

	$nw = urzone_pve_set_api( $c, $base . '/network' );

	if ( $nw['ok'] ) {
		$ifaces = array_map( 'strval', wp_list_pluck( (array) $nw['data'], 'iface' ) );

		if ( in_array( (string) $c['bridge'], $ifaces, true ) ) {
			$add( 'ok', 'Bridge "' . $c['bridge'] . '" exists' );
		} else {
			$add( 'fail', 'Bridge "' . $c['bridge'] . '" not found', 'Interfaces on this node: ' . ( $ifaces ? implode( ', ', $ifaces ) : 'none' ) );
		}
	} else {
		$add( 'warn', 'Could not read the network list', $nw['error'] . ' (the token needs Sys.Audit to check bridges.)' );
	}

	$gr = urzone_pve_set_api( $c, '/cluster/resources?type=vm' );

	if ( $gr['ok'] ) {
		$n = 0;

		foreach ( (array) $gr['data'] as $g ) {
			if ( is_array( $g ) && ( $g['node'] ?? '' ) === $node && absint( $g['vmid'] ?? 0 ) >= 100 && empty( $g['template'] ) ) {
				$n++;
			}
		}

		if ( $n > 0 ) {
			$add( 'ok', 'The token can list guests', $n . ' guest(s) visible on node "' . $node . '".' );
		} else {
			$add( 'warn', 'The token sees 0 guests on node "' . $node . '"', 'If guests exist in Proxmox, the token is missing VM.Audit (usually Privilege Separation). The plugin pages will stay empty until this is fixed: give the token the PVEAdmin role on path /, or turn Privilege Separation off.' );
		}
	} else {
		$add( 'warn', 'Could not list guests', $gr['error'] );
	}

	return $rows;
}

/*
|--------------------------------------------------------------------------
| Save handler
|--------------------------------------------------------------------------
*/

function urzone_pve_set_collect_connection( $mode ) {
	if ( 'managed' === $mode ) {
		$src = urzone_pve_set_preset();

		if ( in_array( '', $src, true ) ) {
			return new WP_Error( 'preset', 'The hosted connection details have not been configured by the plugin provider yet.' );
		}
	} else {
		$get = static function ( $k ) {
			$v = isset( $_POST[ $k ] ) ? wp_unslash( $_POST[ $k ] ) : ''; // phpcs:ignore WordPress.Security

			return is_scalar( $v ) ? trim( (string) $v ) : '';
		};

		$src = array(
			'url'      => $get( 'api_url' ),
			'user'     => $get( 'api_user' ),
			'token_id' => $get( 'api_token_id' ),
			'secret'   => $get( 'api_secret' ),
		);

		if ( '' === $src['secret'] ) {
			$src['secret'] = urzone_pve_set_const( 'URZONE_PROXMOX_API_TOKEN_SECRET' ); // Blank = keep the saved one.
		}
	}

	$url = rtrim( $src['url'], '/' );

	if ( ! preg_match( '#^https://[A-Za-z0-9.\-\[\]:]+(/[A-Za-z0-9._~/\-]*)?$#', $url ) ) {
		return new WP_Error( 'url', 'API URL must start with https:// and contain only a host, an optional port and a path, e.g. https://192.168.1.10:8006/api2/json' );
	}

	if ( '' === (string) wp_parse_url( $url, PHP_URL_PATH ) ) {
		$url .= '/api2/json';
	}

	if ( ! preg_match( '/^[A-Za-z0-9._-]+@[A-Za-z0-9._-]+$/', $src['user'] ) ) {
		return new WP_Error( 'user', 'API user must look like root@pam.' );
	}

	if ( ! preg_match( '/^[A-Za-z0-9._@!-]+$/', $src['token_id'] ) ) {
		return new WP_Error( 'token', 'Token ID may only contain letters, numbers and . _ @ ! -' );
	}

	if ( ! preg_match( '#^[A-Za-z0-9._~+=/-]{8,200}$#', $src['secret'] ) ) {
		return new WP_Error( 'secret', 'The token secret is missing or contains unexpected characters. Paste it exactly as Proxmox showed it.' );
	}

	return array(
		'consts' => array(
			'URZONE_PROXMOX_API_URL'          => $url,
			'URZONE_PROXMOX_API_USER'         => $src['user'],
			'URZONE_PROXMOX_API_TOKEN_ID'     => $src['token_id'],
			'URZONE_PROXMOX_API_TOKEN_SECRET' => $src['secret'],
		),
		'eff'    => array( 'url' => $url, 'user' => $src['user'], 'token_id' => $src['token_id'], 'secret' => $src['secret'] ),
	);
}

function urzone_pve_set_collect_options() {
	$consts = array();
	$eff    = array();

	foreach ( urzone_pve_set_option_fields() as $key => $f ) {
		$raw = isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : ''; // phpcs:ignore WordPress.Security
		$raw = is_scalar( $raw ) ? trim( (string) $raw ) : '';

		if ( 'bool' === $f['type'] ) {
			$val = '' !== $raw;
		} elseif ( 'id' === $f['type'] ) {
			$val = sanitize_text_field( $raw );

			if ( ! preg_match( '/^[A-Za-z0-9._-]+$/', $val ) ) {
				return new WP_Error( 'bad', $f['label'] . ' may only contain letters, numbers, dots, dashes and underscores.' );
			}
		} else {
			if ( ! preg_match( '/^\d+$/', $raw ) || (int) $raw < $f['min'] || (int) $raw > $f['max'] ) {
				return new WP_Error( 'bad', $f['label'] . ' must be a whole number between ' . $f['min'] . ' and ' . $f['max'] . '.' );
			}

			$val = (int) $raw;
		}

		$consts[ $f['const'] ] = $val;
		$eff[ $key ]           = $val;
	}

	return array( 'consts' => $consts, 'eff' => $eff );
}

function urzone_pve_set_block_exists( $section ) {
	$path = urzone_pve_set_config_path();

	if ( '' === $path || ! is_readable( $path ) ) {
		return false;
	}

	return false !== strpos( (string) file_get_contents( $path ), '/* BEGIN urZONE PVE ' . $section );
}

/** Part 2 values as they are right now (wp-config / plugin defaults), typed for writing. */
function urzone_pve_set_option_snapshot() {
	$out = array();

	foreach ( urzone_pve_set_option_fields() as $f ) {
		$v = defined( $f['const'] ) ? constant( $f['const'] ) : $f['default'];

		if ( 'bool' === $f['type'] ) {
			$v = (bool) $v;
		} elseif ( 'int' === $f['type'] ) {
			$v = (int) $v;
		} else {
			$v = (string) $v;
		}

		$out[ $f['const'] ] = $v;
	}

	return $out;
}

function urzone_pve_set_handle() {
	if ( ! urzone_pve_set_can() ) {
		wp_die( 'You are not allowed to do that.', '', array( 'response' => 403 ) );
	}

	check_admin_referer( 'urzone_pve_settings' );

	$section = ( isset( $_POST['section'] ) && in_array( $_POST['section'], array( 'options' ), true ) ) ? $_POST['section'] : 'connection';
	$test    = isset( $_POST['do'] ) && 'save_test' === $_POST['do'];
	$mode    = ( isset( $_POST['mode'] ) && 'managed' === $_POST['mode'] ) ? 'managed' : 'own';
	$flash   = array( 'msgs' => array(), 'tests' => array(), 'manual' => '', 'section' => $section );

	if ( 'options' === $section ) {
		$res = urzone_pve_set_collect_options();
	} else {
		$res = urzone_pve_set_collect_connection( $mode );
	}

	if ( is_wp_error( $res ) ) {
		$flash['msgs'][] = array( 'error', $res->get_error_message() );
	} else {
		if ( 'connection' === $section ) {
			update_site_option( 'urzone_pve_mode', $mode );
		}

		$w = urzone_pve_set_write( $section, $res['consts'] );

		if ( is_wp_error( $w ) ) {
			$flash['msgs'][] = array( 'error', 'Not saved to wp-config.php: ' . $w->get_error_message() );

			if ( in_array( $w->get_error_code(), array( 'nofile', 'notwritable' ), true ) ) {
				$flash['manual'] = urzone_pve_set_block( $section, $res['consts'] );
				$flash['msgs'][] = array( 'error', 'Copy the block below into wp-config.php yourself, above the "That\'s all, stop editing!" line.' );
			}
		} else {
			$flash['msgs'][] = array( 'success', 'Saved to wp-config.php. A backup of the previous file is in wp-config-urzone-backup.php (delete its first line to restore it).' );

			delete_transient( 'uzpve_unreachable' );
			delete_transient( 'uzpve_c_' . md5( '/cluster/resources' ) );

			// First save of the connection: also write the Defaults so wp-config is complete.
			if ( 'connection' === $section && ! urzone_pve_set_block_exists( 'options' ) ) {
				$o = urzone_pve_set_write( 'options', urzone_pve_set_option_snapshot() );

				if ( ! is_wp_error( $o ) ) {
					$flash['msgs'][] = array( 'success', 'The default settings from the Defaults tab were also written to wp-config.php. Review them there and save again if you want to change anything.' );
				}
			}
		}

		if ( $test ) {
			$flash['tests'] = urzone_pve_set_test( array_merge( urzone_pve_set_current(), $res['eff'] ) );
		}
	}

	set_transient( 'uzpve_adm_' . get_current_user_id(), $flash, 300 );

	wp_safe_redirect( wp_get_referer() ? wp_get_referer() : self_admin_url( 'admin.php?page=urzone-pve' ) );
	exit;
}

add_action( 'admin_post_urzone_pve_settings', 'urzone_pve_set_handle' );

/*
|--------------------------------------------------------------------------
| Menu
|--------------------------------------------------------------------------
*/

function urzone_pve_set_icon() {
	$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="#a7aaad" fill-rule="evenodd" d="M3 2h14a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1zm11 2a1 1 0 1 0 0 2 1 1 0 0 0 0-2zM3 12h14a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-4a1 1 0 0 1 1-1zm11 2a1 1 0 1 0 0 2 1 1 0 0 0 0-2z"/></svg>';

	return 'data:image/svg+xml;base64,' . base64_encode( $svg );
}

function urzone_pve_set_menu() {
	if ( ! urzone_pve_set_can() ) {
		return;
	}

	// Multisite: show it in Network Admin and in the main site's dashboard (not on customer subsites).
	if ( is_multisite() && ! is_network_admin() && ! is_main_site() ) {
		return;
	}

	add_menu_page(
		'urZONE PVE',
		'urZONE PVE',
		is_multisite() ? 'manage_network_options' : 'manage_options',
		'urzone-pve',
		'urzone_pve_set_page',
		urzone_pve_set_icon(),
		80
	);
}

add_action( 'admin_menu', 'urzone_pve_set_menu' );
add_action( 'network_admin_menu', 'urzone_pve_set_menu' );

/** The admin menu page. */
function urzone_pve_set_page() {
	if ( ! urzone_pve_set_can() ) {
		wp_die( 'You are not allowed to do that.', '', array( 'response' => 403 ) );
	}

	echo '<div class="wrap"><h1 class="screen-reader-text">urZONE PVE</h1>';
	echo urzone_pve_set_render( 'admin' ); // phpcs:ignore WordPress.Security.EscapeOutput
	echo '</div>';
}

/*
|--------------------------------------------------------------------------
| Look and feel
|--------------------------------------------------------------------------
*/

function urzone_pve_set_css() {
	ob_start();
	?>
	<style>
		.uzpc{--bg:#0c131b;--panel:#111d29;--panel2:#0d1620;--line:#26384a;--line2:#3a5470;--text:#e8eff7;--mute:#93abc0;--blue:#2781d1;--blue2:#3a95e6;--green:#3ed68a;--amber:#e0a13a;--red:#e5586a;max-width:1100px;margin:20px auto;color:var(--text);font-family:system-ui,-apple-system,"Segoe UI",sans-serif;font-size:14px;line-height:1.5}
		.uzpc *{box-sizing:border-box}
		.uzpc [hidden]{display:none!important}
		.uzpc .uzpc-shell{background:var(--bg);border:1px solid var(--line);border-radius:18px;overflow:hidden}
		.uzpc .uzpc-hero{display:flex;align-items:center;gap:16px;flex-wrap:wrap;padding:24px;background:linear-gradient(135deg,#0f1c29,#14283a 60%,#17324a);border-bottom:1px solid var(--line)}
		.uzpc .uzpc-mark{width:48px;height:48px;border-radius:14px;background:linear-gradient(135deg,var(--blue),#4fdc90);display:flex;align-items:center;justify-content:center;flex:0 0 auto}
		.uzpc .uzpc-mark svg{width:26px;height:26px;fill:none;stroke:#fff;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
		.uzpc .uzpc-hero-t{flex:1;min-width:200px}
		.uzpc .uzpc-hero h2{margin:0;padding:0;font-size:24px;line-height:1.2;color:#fff;border:0}
		.uzpc .uzpc-hero p{margin:4px 0 0;color:#a3b9cd}
		.uzpc .uzpc-chips{display:flex;gap:8px;flex-wrap:wrap}
		.uzpc .uzpc-chip{display:inline-flex;align-items:center;gap:7px;padding:6px 12px;border-radius:999px;background:#0a1118;border:1px solid var(--line);color:#cfe0ef;font-size:12px;font-weight:600}
		.uzpc .uzpc-chip i{width:8px;height:8px;border-radius:50%;background:var(--mute);display:inline-block}
		.uzpc .uzpc-chip.ok i{background:var(--green)}.uzpc .uzpc-chip.warn i{background:var(--amber)}.uzpc .uzpc-chip.off i{background:var(--red)}
		.uzpc .uzpc-tabs{display:flex;gap:6px;padding:12px 18px 0;background:#0f1822;border-bottom:1px solid var(--line);overflow-x:auto}
		.uzpc .uzpc-tab{appearance:none;border:0;background:transparent;color:var(--mute);padding:11px 16px;font-size:14px;font-weight:600;cursor:pointer;border-bottom:3px solid transparent;border-radius:8px 8px 0 0;white-space:nowrap}
		.uzpc .uzpc-tab:hover{color:#fff;background:#14222f}
		.uzpc .uzpc-tab.on{color:#fff;border-bottom-color:var(--blue)}
		.uzpc .uzpc-body{padding:20px}
		.uzpc .uzpc-msg{display:flex;gap:10px;margin:0 0 12px;padding:12px 14px;border-radius:10px;font-size:14px}
		.uzpc .uzpc-msg.success{background:#12382a;color:#aeefd0;border:1px solid #286c4a}
		.uzpc .uzpc-msg.error{background:#47202a;color:#ffc2c8;border:1px solid #88404c}
		.uzpc .uzpc-note{margin:0 0 16px;color:var(--mute)}
		.uzpc .uzpc-note code,.uzpc code{color:#aee1ff;background:#0a1118;padding:2px 6px;border-radius:5px;font-size:12px}
		.uzpc .uzpc-card{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:18px;margin:0 0 16px}
		.uzpc .uzpc-card h3{margin:0 0 4px;padding:0;font-size:16px;color:#fff;border:0}
		.uzpc .uzpc-card .uzpc-sub{margin:0 0 14px;color:var(--mute);font-size:13px}
		.uzpc .uzpc-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:16px}
		.uzpc .uzpc-field label.uzpc-l{display:block;margin:0 0 6px;font-size:13px;font-weight:600;color:#d7e6f4}
		.uzpc .uzpc-field .uzpc-k{display:block;margin:0 0 6px;font-size:11px;color:#6f8aa1;font-family:ui-monospace,Menlo,Consolas,monospace;word-break:break-all}
		.uzpc .uzpc-field .uzpc-h{margin:6px 0 0;font-size:12px;color:var(--mute)}
		.uzpc input[type=text],.uzpc input[type=password],.uzpc input[type=number]{display:block;width:100%;height:auto;margin:0;padding:10px 12px;border:1px solid var(--line2);border-radius:9px;background:#0a1118;color:#eef5ff;font-size:14px;box-shadow:none;outline:0}
		.uzpc input[readonly]{opacity:.7}
		.uzpc input:focus{border-color:var(--blue);box-shadow:0 0 0 3px rgba(39,129,209,.25)}
		.uzpc .uzpc-pw{position:relative}
		.uzpc .uzpc-pw input{padding-right:64px}
		.uzpc .uzpc-eye{position:absolute;right:6px;top:50%;transform:translateY(-50%);border:0;background:#1f3348;color:#e8f1fa;border-radius:6px;padding:4px 9px;font-size:12px;cursor:pointer}
		.uzpc .uzpc-eye:hover{background:#2f4761}
		.uzpc .uzpc-modes{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px;margin:0 0 18px}
		.uzpc .uzpc-mode{display:block;position:relative;padding:14px 16px 14px 44px;border:1px solid var(--line2);border-radius:12px;background:var(--panel2);cursor:pointer}
		.uzpc .uzpc-mode input{position:absolute;left:16px;top:17px;margin:0;accent-color:var(--blue)}
		.uzpc .uzpc-mode b{display:block;color:#fff;font-size:14px}
		.uzpc .uzpc-mode span{display:block;margin-top:2px;color:var(--mute);font-size:12px}
		.uzpc .uzpc-mode.on{border-color:var(--blue);background:#12283b}
		.uzpc .uzpc-switch{display:inline-flex;align-items:center;gap:12px;cursor:pointer}
		.uzpc .uzpc-switch input{position:absolute;opacity:0;width:0;height:0}
		.uzpc .uzpc-switch span.t{position:relative;width:46px;height:26px;border-radius:999px;background:#2a3f54;transition:background .15s;flex:0 0 auto}
		.uzpc .uzpc-switch span.t::after{content:"";position:absolute;top:3px;left:3px;width:20px;height:20px;border-radius:50%;background:#fff;transition:transform .15s}
		.uzpc .uzpc-switch input:checked+span.t{background:var(--green)}
		.uzpc .uzpc-switch input:checked+span.t::after{transform:translateX(20px)}
		.uzpc .uzpc-switch input:focus-visible+span.t{box-shadow:0 0 0 3px rgba(39,129,209,.4)}
		.uzpc .uzpc-switch em{font-style:normal;color:#d7e6f4}
		.uzpc .uzpc-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:6px}
		.uzpc .uzpc-btn{appearance:none;border:0;border-radius:9px;padding:10px 18px;font-size:14px;font-weight:600;cursor:pointer;background:#23364a;color:#e8f1fa}
		.uzpc .uzpc-btn:hover{background:#2f4761}
		.uzpc .uzpc-btn.pri{background:var(--blue);color:#fff}.uzpc .uzpc-btn.pri:hover{background:var(--blue2)}
		.uzpc .uzpc-tests{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:8px}
		.uzpc .uzpc-tests li{display:flex;gap:12px;padding:10px 12px;border-radius:10px;background:var(--panel2);border:1px solid var(--line)}
		.uzpc .uzpc-ic{flex:0 0 24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;color:#06121c}
		.uzpc .uzpc-ic.ok{background:var(--green)}.uzpc .uzpc-ic.warn{background:var(--amber)}.uzpc .uzpc-ic.fail{background:var(--red)}
		.uzpc .uzpc-tests strong{color:#fff;font-weight:600}
		.uzpc .uzpc-tests small{display:block;color:var(--mute);font-size:12px;margin-top:2px}
		.uzpc .uzpc-code{position:relative;margin:0 0 16px}
		.uzpc .uzpc-code textarea{display:block;width:100%;min-height:150px;padding:12px;border:1px solid var(--line2);border-radius:10px;background:#050a10;color:#aee1ff;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12px}
		.uzpc .uzpc-code button{position:absolute;right:10px;top:10px}
		.uzpc .uzpc-guide summary{cursor:pointer;font-size:16px;font-weight:600;color:#fff}
		.uzpc .uzpc-md h4{margin:24px 0 8px;padding:0;border:0;font-size:15px;color:#fff}
		.uzpc .uzpc-md h5{margin:16px 0 6px;padding:0;border:0;font-size:14px;color:#d7e6f4}
		.uzpc .uzpc-md p,.uzpc .uzpc-md li{margin:0 0 8px;color:#cfe0ef;line-height:1.6}
		.uzpc .uzpc-md ul,.uzpc .uzpc-md ol{margin:6px 0 12px 22px;padding:0}
		.uzpc .uzpc-md ul{list-style:disc}.uzpc .uzpc-md ol{list-style:decimal}
		.uzpc .uzpc-pre{position:relative;margin:8px 0 14px}
		.uzpc .uzpc-pre pre{margin:0;padding:12px;max-height:420px;overflow:auto;border:1px solid var(--line2);border-radius:10px;background:#050a10;color:#aee1ff;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12px;line-height:1.5;white-space:pre}
		.uzpc .uzpc-pre code{background:none;padding:0;font-size:12px;color:inherit}
		.uzpc .uzpc-pre .uzpc-copycode{position:absolute;right:10px;top:8px;padding:4px 10px;font-size:12px}
		@media (max-width:600px){.uzpc .uzpc-body{padding:14px}.uzpc .uzpc-hero{padding:18px}}
	</style>
	<?php
	return ob_get_clean();
}

function urzone_pve_set_js() {
	ob_start();
	?>
	<script>
	(function () {
		document.querySelectorAll('.uzpc:not([data-ready])').forEach(function (root) {
			root.setAttribute('data-ready', '1');

			/* tabs */
			var tabs = root.querySelectorAll('[data-tab]');
			var panels = root.querySelectorAll('[data-panel]');
			function show(name) {
				tabs.forEach(function (t) { t.classList.toggle('on', t.getAttribute('data-tab') === name); });
				panels.forEach(function (p) { p.hidden = p.getAttribute('data-panel') !== name; });
			}
			tabs.forEach(function (t) { t.addEventListener('click', function () { show(t.getAttribute('data-tab')); }); });
			show(root.getAttribute('data-start') || 'connection');

			/* own / managed */
			var conn = root.querySelector('[data-conn]');
			if (conn) {
				var sync = function () {
					var checked = conn.querySelector('input[name=mode]:checked');
					var m = checked ? checked.value : 'own';
					conn.querySelectorAll('[data-pane]').forEach(function (p) { p.hidden = p.getAttribute('data-pane') !== m; });
					conn.querySelectorAll('.uzpc-mode').forEach(function (l) { l.classList.toggle('on', l.querySelector('input').checked); });
				};
				conn.addEventListener('change', sync);
				sync();
			}

			/* show / hide secrets */
			root.querySelectorAll('[data-eye]').forEach(function (b) {
				b.addEventListener('click', function () {
					var i = b.parentNode.querySelector('input');
					var on = i.type === 'password';
					i.type = on ? 'text' : 'password';
					b.textContent = on ? 'Hide' : 'Show';
				});
			});

			/* copy the manual wp-config block */
			root.querySelectorAll('[data-copy]').forEach(function (b) {
				b.addEventListener('click', function () {
					var t = b.parentNode.querySelector('textarea');
					t.select();
					try { document.execCommand('copy'); b.textContent = 'Copied'; } catch (e) {}
				});
			});
		});
	})();
	</script>
	<?php
	return ob_get_clean();
}

/** One field on the Defaults tab. */
function urzone_pve_set_field_html( $k, $f, $c ) {
	$id = 'uzpc-' . $k;

	ob_start();
	?>
	<div class="uzpc-field">
		<?php if ( 'bool' === $f['type'] ) : ?>
			<span class="uzpc-l" style="display:block;margin:0 0 6px;font-size:13px;font-weight:600;color:#d7e6f4"><?php echo esc_html( $f['label'] ); ?></span>
			<code class="uzpc-k"><?php echo esc_html( $f['const'] ); ?></code>
			<label class="uzpc-switch">
				<input type="checkbox" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $k ); ?>" value="1" <?php checked( ! empty( $c[ $k ] ) ); ?>>
				<span class="t"></span><em>Enabled</em>
			</label>
		<?php else : ?>
			<label class="uzpc-l" for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $f['label'] ); ?></label>
			<code class="uzpc-k"><?php echo esc_html( $f['const'] ); ?></code>
			<?php if ( 'int' === $f['type'] ) : ?>
				<input type="number" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $k ); ?>" min="<?php echo esc_attr( $f['min'] ); ?>" max="<?php echo esc_attr( $f['max'] ); ?>" value="<?php echo esc_attr( $c[ $k ] ); ?>">
			<?php else : ?>
				<input type="text" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $k ); ?>" value="<?php echo esc_attr( $c[ $k ] ); ?>">
			<?php endif; ?>
		<?php endif; ?>
		<p class="uzpc-h"><?php echo esc_html( $f['help'] ); ?></p>
	</div>
	<?php
	return ob_get_clean();
}

/** Renders the whole settings panel (used by the admin menu page). */
function urzone_pve_set_render( $context = 'admin' ) {
	static $assets = false;

	$key   = 'uzpve_adm_' . get_current_user_id();
	$flash = get_transient( $key );

	if ( $flash ) {
		delete_transient( $key );
	}

	$flash        = is_array( $flash ) ? $flash : array();
	$start        = in_array( $flash['section'] ?? '', array( 'connection', 'options' ), true ) ? $flash['section'] : 'connection';
	$mode         = 'managed' === get_site_option( 'urzone_pve_mode', 'own' ) ? 'managed' : 'own';
	$preset       = urzone_pve_set_preset();
	$preset_ok    = ! in_array( '', $preset, true );
	$path         = urzone_pve_set_config_path();
	$writable     = '' !== $path && is_writable( $path );
	$secret_saved = '' !== urzone_pve_set_const( 'URZONE_PROXMOX_API_TOKEN_SECRET' );
	$conn_ok      = $secret_saved && '' !== urzone_pve_set_const( 'URZONE_PROXMOX_API_URL' );
	$c            = urzone_pve_set_current();
	$action       = admin_url( 'admin-post.php' );
	$icons        = array( 'ok' => '&#10003;', 'warn' => '!', 'fail' => '&#10005;' );
	$fields       = urzone_pve_set_option_fields();

	ob_start();

	if ( ! $assets ) {
		echo urzone_pve_set_css(); // phpcs:ignore WordPress.Security.EscapeOutput
		$assets = true;
	}
	?>
	<div class="uzpc" data-start="<?php echo esc_attr( $start ); ?>" data-ctx="<?php echo esc_attr( $context ); ?>">
		<div class="uzpc-shell">

			<div class="uzpc-hero">
				<div class="uzpc-mark"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="7" rx="2"/><rect x="3" y="13" width="18" height="7" rx="2"/><path d="M7 7.5h.01M7 16.5h.01"/></svg></div>
				<div class="uzpc-hero-t">
					<h2>urZONE PVE Core</h2>
					<p>Connect your Proxmox server and set the defaults for new instances.</p>
				</div>
				<div class="uzpc-chips">
					<span class="uzpc-chip <?php echo $writable ? 'ok' : 'warn'; ?>"><i></i><?php echo $writable ? 'wp-config.php writable' : 'wp-config.php not writable'; ?></span>
					<span class="uzpc-chip <?php echo $conn_ok ? 'ok' : 'off'; ?>"><i></i><?php echo $conn_ok ? 'Proxmox configured' : 'Proxmox not configured'; ?></span>
				</div>
			</div>

			<nav class="uzpc-tabs" aria-label="Settings sections">
				<button type="button" class="uzpc-tab" data-tab="connection">1. Connection</button>
				<button type="button" class="uzpc-tab" data-tab="options">2. Defaults &amp; limits</button>
			</nav>

			<div class="uzpc-body">

				<?php foreach ( (array) ( $flash['msgs'] ?? array() ) as $m ) : ?>
					<div class="uzpc-msg <?php echo 'success' === $m[0] ? 'success' : 'error'; ?>"><?php echo esc_html( $m[1] ); ?></div>
				<?php endforeach; ?>

				<?php if ( ! empty( $flash['manual'] ) ) : ?>
					<div class="uzpc-code">
						<textarea readonly onfocus="this.select()"><?php echo esc_textarea( $flash['manual'] ); ?></textarea>
						<button type="button" class="uzpc-btn" data-copy>Copy</button>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $flash['tests'] ) ) : ?>
					<div class="uzpc-card">
						<h3>Connection test</h3>
						<p class="uzpc-sub">Green means it works. Orange is worth a look. Red must be fixed.</p>
						<ul class="uzpc-tests">
							<?php foreach ( $flash['tests'] as $row ) : ?>
								<li>
									<span class="uzpc-ic <?php echo esc_attr( $row[0] ); ?>"><?php echo $icons[ $row[0] ]; // phpcs:ignore ?></span>
									<div>
										<strong><?php echo esc_html( $row[1] ); ?></strong>
										<?php if ( '' !== $row[2] ) : ?>
											<small><?php echo esc_html( $row[2] ); ?></small>
										<?php endif; ?>
									</div>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endif; ?>

				<p class="uzpc-note">
					<?php if ( $writable ) : ?>
						Settings are saved to <code><?php echo esc_html( $path ); ?></code>
					<?php elseif ( '' === $path ) : ?>
						<strong>wp-config.php was not found.</strong> Saving will show you the lines to paste in manually.
					<?php else : ?>
						<strong>wp-config.php is not writable by the web server.</strong> Saving will show you the lines to paste in manually.
					<?php endif; ?>
				</p>

				<!-- 1. CONNECTION -->
				<section data-panel="connection" hidden>
					<form method="post" action="<?php echo esc_url( $action ); ?>" data-conn>
						<input type="hidden" name="action" value="urzone_pve_settings">
						<input type="hidden" name="section" value="connection">
						<?php wp_nonce_field( 'urzone_pve_settings' ); ?>

						<div class="uzpc-modes">
							<label class="uzpc-mode"><input type="radio" name="mode" value="own" <?php checked( 'own', $mode ); ?>><b>I own a Proxmox server</b><span>Enter your own API token details.</span></label>
							<label class="uzpc-mode"><input type="radio" name="mode" value="managed" <?php checked( 'managed', $mode ); ?>><b>I don't own a Proxmox server</b><span>Use the hosted connection that is pre-defined for you.</span></label>
						</div>

						<div class="uzpc-card" data-pane="own">
							<h3>Your Proxmox API token</h3>
							<p class="uzpc-sub">Create it in Proxmox under Datacenter &rarr; Permissions &rarr; API Tokens, then fill these in.</p>
							<div class="uzpc-grid">
								<div class="uzpc-field">
									<label class="uzpc-l" for="uzpc-url">API URL</label><code class="uzpc-k">URZONE_PROXMOX_API_URL</code>
									<input type="text" id="uzpc-url" name="api_url" value="<?php echo esc_attr( $c['url'] ); ?>" placeholder="https://YOUR_PVE_IP:8006/api2/json">
									<p class="uzpc-h">Must be https. Your Proxmox IP or hostname, port 8006.</p>
								</div>
								<div class="uzpc-field">
									<label class="uzpc-l" for="uzpc-user">API user</label><code class="uzpc-k">URZONE_PROXMOX_API_USER</code>
									<input type="text" id="uzpc-user" name="api_user" value="<?php echo esc_attr( $c['user'] ); ?>" placeholder="root@pam">
									<p class="uzpc-h">The user that owns the token, e.g. root@pam.</p>
								</div>
								<div class="uzpc-field">
									<label class="uzpc-l" for="uzpc-tid">Token ID</label><code class="uzpc-k">URZONE_PROXMOX_API_TOKEN_ID</code>
									<input type="text" id="uzpc-tid" name="api_token_id" value="<?php echo esc_attr( $c['token_id'] ); ?>" placeholder="urzone">
									<p class="uzpc-h">Just the token name (the part after the !).</p>
								</div>
								<div class="uzpc-field">
									<label class="uzpc-l" for="uzpc-sec">Token secret</label><code class="uzpc-k">URZONE_PROXMOX_API_TOKEN_SECRET</code>
									<div class="uzpc-pw">
										<input type="password" id="uzpc-sec" name="api_secret" value="" autocomplete="new-password" placeholder="<?php echo $secret_saved ? 'Saved. Leave blank to keep it.' : 'PASTE_YOUR_SECRET_HERE'; ?>">
										<button type="button" class="uzpc-eye" data-eye>Show</button>
									</div>
									<p class="uzpc-h">Proxmox shows it only once, when the token is created. It is kept in wp-config.php and never displayed again.</p>
								</div>
							</div>
						</div>

						<div class="uzpc-card" data-pane="managed" hidden>
							<h3>Hosted connection</h3>
							<?php if ( $preset_ok ) : ?>
								<p class="uzpc-sub">These details are pre-defined for you. Just press Save.</p>
								<div class="uzpc-grid">
									<div class="uzpc-field"><span class="uzpc-l" style="display:block;margin:0 0 6px;font-weight:600">API URL</span><input type="text" value="<?php echo esc_attr( $preset['url'] ); ?>" readonly></div>
									<div class="uzpc-field"><span class="uzpc-l" style="display:block;margin:0 0 6px;font-weight:600">API user</span><input type="text" value="<?php echo esc_attr( $preset['user'] ); ?>" readonly></div>
									<div class="uzpc-field"><span class="uzpc-l" style="display:block;margin:0 0 6px;font-weight:600">Token ID</span><input type="text" value="<?php echo esc_attr( $preset['token_id'] ); ?>" readonly></div>
									<div class="uzpc-field"><span class="uzpc-l" style="display:block;margin:0 0 6px;font-weight:600">Token secret</span><input type="password" value="<?php echo esc_attr( str_repeat( '*', 12 ) ); ?>" readonly></div>
								</div>
							<?php else : ?>
								<p class="uzpc-sub">The hosted connection details have not been set up by the plugin provider yet.</p>
							<?php endif; ?>
						</div>

						<div class="uzpc-actions">
							<button type="submit" name="do" value="save" class="uzpc-btn pri">Save</button>
							<button type="submit" name="do" value="save_test" class="uzpc-btn">Save &amp; test connection</button>
						</div>
					</form>
				</section>

				<!-- 2. DEFAULTS -->
				<section data-panel="options" hidden>
					<form method="post" action="<?php echo esc_url( $action ); ?>">
						<input type="hidden" name="action" value="urzone_pve_settings">
						<input type="hidden" name="section" value="options">
						<?php wp_nonce_field( 'urzone_pve_settings' ); ?>

						<?php foreach ( urzone_pve_set_groups() as $group ) : ?>
							<div class="uzpc-card">
								<h3><?php echo esc_html( $group[0] ); ?></h3>
								<p class="uzpc-sub"><?php echo esc_html( $group[1] ); ?></p>
								<div class="uzpc-grid">
									<?php
									foreach ( $group[2] as $k ) {
										if ( isset( $fields[ $k ] ) ) {
											echo urzone_pve_set_field_html( $k, $fields[ $k ], $c ); // phpcs:ignore WordPress.Security.EscapeOutput
										}
									}
									?>
								</div>
							</div>
						<?php endforeach; ?>

						<div class="uzpc-actions">
							<button type="submit" name="do" value="save" class="uzpc-btn pri">Save</button>
							<button type="submit" name="do" value="save_test" class="uzpc-btn">Save &amp; test connection</button>
						</div>
					</form>
				</section>

			</div>
		</div>
	</div>
	<?php
	echo urzone_pve_set_js(); // phpcs:ignore WordPress.Security.EscapeOutput

	return ob_get_clean();
}
